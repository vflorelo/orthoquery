SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS `orthologues`;
CREATE DATABASE `orthologues` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `orthologues`;
DROP TABLE IF EXISTS `Acanthamoeba_castellani.NEFF`;
CREATE TABLE `Acanthamoeba_castellani.NEFF` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Alexandrium_catenella.nr95`;
CREATE TABLE `Alexandrium_catenella.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Amoebophrya_sp`;
CREATE TABLE `Amoebophrya_sp` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Amphidinium_carterae.nr95`;
CREATE TABLE `Amphidinium_carterae.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Arabidopsis_thaliana.TAIR10`;
CREATE TABLE `Arabidopsis_thaliana.TAIR10` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Aspergillus_niger`;
CREATE TABLE `Aspergillus_niger` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Aureococcus_anophagefferens`;
CREATE TABLE `Aureococcus_anophagefferens` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Babesia_bigemina.BOND`;
CREATE TABLE `Babesia_bigemina.BOND` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Babesia_bovis.T2Bo`;
CREATE TABLE `Babesia_bovis.T2Bo` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Babesia_microti`;
CREATE TABLE `Babesia_microti` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Batrachochytrium_dendrobatidis.JEL423`;
CREATE TABLE `Batrachochytrium_dendrobatidis.JEL423` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Besnoitia_besnoiti`;
CREATE TABLE `Besnoitia_besnoiti` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Bigelowiella_natans`;
CREATE TABLE `Bigelowiella_natans` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Bodo_saltans.Lake_Konstanz`;
CREATE TABLE `Bodo_saltans.Lake_Konstanz` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Botryococcus_braunii.502`;
CREATE TABLE `Botryococcus_braunii.502` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Caenorhabditis_elegans.WS283`;
CREATE TABLE `Caenorhabditis_elegans.WS283` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cardiosporidium_cionae`;
CREATE TABLE `Cardiosporidium_cionae` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Chlamydomonas_reinhardtii.GeneCatalog`;
CREATE TABLE `Chlamydomonas_reinhardtii.GeneCatalog` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Chlamydomonas_reinhardtii.external`;
CREATE TABLE `Chlamydomonas_reinhardtii.external` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Chromera_velia`;
CREATE TABLE `Chromera_velia` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Chrysochromulina_tobinii.CCMP291`;
CREATE TABLE `Chrysochromulina_tobinii.CCMP291` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Crassostrea_virginica`;
CREATE TABLE `Crassostrea_virginica` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Crypthecodinium_cohnii.Libby_4`;
CREATE TABLE `Crypthecodinium_cohnii.Libby_4` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cryptosporidium_andersoni.30847`;
CREATE TABLE `Cryptosporidium_andersoni.30847` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cryptosporidium_meleagridis.UKMEL1`;
CREATE TABLE `Cryptosporidium_meleagridis.UKMEL1` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cryptosporidium_muris.RN66`;
CREATE TABLE `Cryptosporidium_muris.RN66` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cryptosporidium_parvum`;
CREATE TABLE `Cryptosporidium_parvum` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cyanidioschyzon_merolae.10D`;
CREATE TABLE `Cyanidioschyzon_merolae.10D` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cyclospora_cayetanensis`;
CREATE TABLE `Cyclospora_cayetanensis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Cytauxzoon_felis.Winnie`;
CREATE TABLE `Cytauxzoon_felis.Winnie` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Danio_rerio`;
CREATE TABLE `Danio_rerio` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Dictyostelium_discoideum.AX4`;
CREATE TABLE `Dictyostelium_discoideum.AX4` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Dinophysis_acuminata.nr95`;
CREATE TABLE `Dinophysis_acuminata.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Drosophila_melanogaster`;
CREATE TABLE `Drosophila_melanogaster` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Durinskia_baltica.nr95`;
CREATE TABLE `Durinskia_baltica.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Ectocarpus_siliculosus`;
CREATE TABLE `Ectocarpus_siliculosus` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Eimeria_acervulina.Houghton`;
CREATE TABLE `Eimeria_acervulina.Houghton` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Eimeria_tenella`;
CREATE TABLE `Eimeria_tenella` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Entamoeba_histolytica.HM1IMSS`;
CREATE TABLE `Entamoeba_histolytica.HM1IMSS` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Galdieria_sulphuraria.074W`;
CREATE TABLE `Galdieria_sulphuraria.074W` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Gregarina_niphandrodes`;
CREATE TABLE `Gregarina_niphandrodes` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Guillardia_theta.CCMP2712`;
CREATE TABLE `Guillardia_theta.CCMP2712` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Hammondia_hammondi.HH34`;
CREATE TABLE `Hammondia_hammondi.HH34` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Hepatocystis`;
CREATE TABLE `Hepatocystis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Heterocapsa_triquestra.nr95`;
CREATE TABLE `Heterocapsa_triquestra.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Homo_sapiens.GRCh38.ref`;
CREATE TABLE `Homo_sapiens.GRCh38.ref` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Ichthyophthirius_multifiliis`;
CREATE TABLE `Ichthyophthirius_multifiliis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Karenia_brevis.nr95`;
CREATE TABLE `Karenia_brevis.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Karlodinium_micrum.nr95`;
CREATE TABLE `Karlodinium_micrum.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Kluyveromyces_lactis`;
CREATE TABLE `Kluyveromyces_lactis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Kryptoperidinium_foliaceum.nr95`;
CREATE TABLE `Kryptoperidinium_foliaceum.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Leishmania_major.Friedlin`;
CREATE TABLE `Leishmania_major.Friedlin` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Leishmania_mexicana.MHOMGT2001U1103`;
CREATE TABLE `Leishmania_mexicana.MHOMGT2001U1103` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Lingulodinium_polyedra.nr95`;
CREATE TABLE `Lingulodinium_polyedra.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Monosiga_brevicollis.MX1`;
CREATE TABLE `Monosiga_brevicollis.MX1` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Mucor_circinelloides.1006PhL`;
CREATE TABLE `Mucor_circinelloides.1006PhL` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Naegleria_fowleri.ATCC30863`;
CREATE TABLE `Naegleria_fowleri.ATCC30863` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Nannochloropsis_gaditana.CCMP526`;
CREATE TABLE `Nannochloropsis_gaditana.CCMP526` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Nematostella_vectensis`;
CREATE TABLE `Nematostella_vectensis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Neospora_caninum`;
CREATE TABLE `Neospora_caninum` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Noctiluca_scintillans.nr95`;
CREATE TABLE `Noctiluca_scintillans.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Oryza_sativa.IRGSP`;
CREATE TABLE `Oryza_sativa.IRGSP` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Oxyrrhis_marina.nr95`;
CREATE TABLE `Oxyrrhis_marina.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Oxytricha_trifallax`;
CREATE TABLE `Oxytricha_trifallax` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Paramecium_tetraurelia`;
CREATE TABLE `Paramecium_tetraurelia` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Perkinsus_atlanticus`;
CREATE TABLE `Perkinsus_atlanticus` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Perkinsus_chesapeaki`;
CREATE TABLE `Perkinsus_chesapeaki` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Perkinsus_marinus`;
CREATE TABLE `Perkinsus_marinus` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Phaeodactylum_tricornutum.CCAP_1055_1`;
CREATE TABLE `Phaeodactylum_tricornutum.CCAP_1055_1` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Physcomitrella_patens`;
CREATE TABLE `Physcomitrella_patens` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Phytophthora_infestans.T30-4`;
CREATE TABLE `Phytophthora_infestans.T30-4` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Plasmodiophora_brassicae.e3`;
CREATE TABLE `Plasmodiophora_brassicae.e3` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Plasmodium_berghei.ANKA`;
CREATE TABLE `Plasmodium_berghei.ANKA` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Plasmodium_falciparum`;
CREATE TABLE `Plasmodium_falciparum` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Plasmodium_vivax.P01`;
CREATE TABLE `Plasmodium_vivax.P01` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Polarella_glacialis`;
CREATE TABLE `Polarella_glacialis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Protoceratium_reticulatum.nr95`;
CREATE TABLE `Protoceratium_reticulatum.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Pseudocohnilembus_persalinus`;
CREATE TABLE `Pseudocohnilembus_persalinus` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Rhodotorula_toruloides.ATCC_204091`;
CREATE TABLE `Rhodotorula_toruloides.ATCC_204091` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Saccharomyces_cerevisiae_S288C`;
CREATE TABLE `Saccharomyces_cerevisiae_S288C` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Saprolegnia_parasitica`;
CREATE TABLE `Saprolegnia_parasitica` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Sarcocystis_neurona.SN3`;
CREATE TABLE `Sarcocystis_neurona.SN3` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Schizochytrium_aggregatum.nr95`;
CREATE TABLE `Schizochytrium_aggregatum.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Schizosaccharomyces_pombe`;
CREATE TABLE `Schizosaccharomyces_pombe` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Stentor_coeruleus`;
CREATE TABLE `Stentor_coeruleus` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Stylonychia_lemnae`;
CREATE TABLE `Stylonychia_lemnae` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Symbiodinium_microadriaticum`;
CREATE TABLE `Symbiodinium_microadriaticum` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Symbiodinium_microadriaticum_2.nr95`;
CREATE TABLE `Symbiodinium_microadriaticum_2.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Tetrahymena_thermophila`;
CREATE TABLE `Tetrahymena_thermophila` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Thalassiosira_pseudonana`;
CREATE TABLE `Thalassiosira_pseudonana` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Thalassiosira_pseudonana.v2`;
CREATE TABLE `Thalassiosira_pseudonana.v2` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Theileria_annulata.Ankara`;
CREATE TABLE `Theileria_annulata.Ankara` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Theileria_equi.WA`;
CREATE TABLE `Theileria_equi.WA` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Theileria_orientalis.Shintoku`;
CREATE TABLE `Theileria_orientalis.Shintoku` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Theileria_parva`;
CREATE TABLE `Theileria_parva` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Togula_jolla.nr95`;
CREATE TABLE `Togula_jolla.nr95` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Toxoplasma_gondii`;
CREATE TABLE `Toxoplasma_gondii` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Trichomonas_vaginalis.G3`;
CREATE TABLE `Trichomonas_vaginalis.G3` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Trypanosoma_brucei.TREU927`;
CREATE TABLE `Trypanosoma_brucei.TREU927` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `Vitrella_brassicaformis`;
CREATE TABLE `Vitrella_brassicaformis` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `accession`     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sequence`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `prot_function` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `comments`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `location`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `datasets`;
CREATE TABLE `datasets` (
  `assoc`         int NOT NULL AUTO_INCREMENT,
  `dataset`       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `protein_count` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `orthogroups`;
CREATE TABLE `orthogroups` (
  `assoc`                                 int NOT NULL AUTO_INCREMENT,
  `Orthogroup`                            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Acanthamoeba_castellani.NEFF`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Alexandrium_catenella.nr95`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Amoebophrya_sp`                        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Amphidinium_carterae.nr95`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Arabidopsis_thaliana.TAIR10`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Aspergillus_niger`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Aureococcus_anophagefferens`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Babesia_bigemina.BOND`                 text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Babesia_bovis.T2Bo`                    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Babesia_microti`                       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Batrachochytrium_dendrobatidis.JEL423` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Besnoitia_besnoiti`                    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Bigelowiella_natans`                   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Bodo_saltans.Lake_Konstanz`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Botryococcus_braunii.502`              text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Caenorhabditis_elegans.WS283`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cardiosporidium_cionae`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Chlamydomonas_reinhardtii.GeneCatalog` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Chlamydomonas_reinhardtii.external`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Chromera_velia`                        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Chrysochromulina_tobinii.CCMP291`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Crassostrea_virginica`                 text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Crypthecodinium_cohnii.Libby_4`        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cryptosporidium_andersoni.30847`       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cryptosporidium_meleagridis.UKMEL1`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cryptosporidium_muris.RN66`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cryptosporidium_parvum`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cyanidioschyzon_merolae.10D`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cyclospora_cayetanensis`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Cytauxzoon_felis.Winnie`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Danio_rerio`                           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Dictyostelium_discoideum.AX4`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Dinophysis_acuminata.nr95`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Drosophila_melanogaster`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Durinskia_baltica.nr95`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Ectocarpus_siliculosus`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Eimeria_acervulina.Houghton`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Eimeria_tenella`                       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Entamoeba_histolytica.HM1IMSS`         text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Galdieria_sulphuraria.074W`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Gregarina_niphandrodes`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Guillardia_theta.CCMP2712`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Hammondia_hammondi.HH34`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Hepatocystis`                          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Heterocapsa_triquestra.nr95`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Homo_sapiens.GRCh38.ref`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Ichthyophthirius_multifiliis`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Karenia_brevis.nr95`                   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Karlodinium_micrum.nr95`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Kluyveromyces_lactis`                  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Kryptoperidinium_foliaceum.nr95`       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Leishmania_major.Friedlin`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Leishmania_mexicana.MHOMGT2001U1103`   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Lingulodinium_polyedra.nr95`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Monosiga_brevicollis.MX1`              text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Mucor_circinelloides.1006PhL`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Naegleria_fowleri.ATCC30863`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Nannochloropsis_gaditana.CCMP526`      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Nematostella_vectensis`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Neospora_caninum`                      text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Noctiluca_scintillans.nr95`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Oryza_sativa.IRGSP`                    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Oxyrrhis_marina.nr95`                  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Oxytricha_trifallax`                   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Paramecium_tetraurelia`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Perkinsus_atlanticus`                  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Perkinsus_chesapeaki`                  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Perkinsus_marinus`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Phaeodactylum_tricornutum.CCAP_1055_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Physcomitrella_patens`                 text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Phytophthora_infestans.T30-4`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Plasmodiophora_brassicae.e3`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Plasmodium_berghei.ANKA`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Plasmodium_falciparum`                 text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Plasmodium_vivax.P01`                  text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Polarella_glacialis`                   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Protoceratium_reticulatum.nr95`        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Pseudocohnilembus_persalinus`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Rhodotorula_toruloides.ATCC_204091`    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Saccharomyces_cerevisiae_S288C`        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Saprolegnia_parasitica`                text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Sarcocystis_neurona.SN3`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Schizochytrium_aggregatum.nr95`        text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Schizosaccharomyces_pombe`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Stentor_coeruleus`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Stylonychia_lemnae`                    text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Symbiodinium_microadriaticum`          text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Symbiodinium_microadriaticum_2.nr95`   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Tetrahymena_thermophila`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Thalassiosira_pseudonana`              text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Thalassiosira_pseudonana.v2`           text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Theileria_annulata.Ankara`             text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Theileria_equi.WA`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Theileria_orientalis.Shintoku`         text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Theileria_parva`                       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Togula_jolla.nr95`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Toxoplasma_gondii`                     text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Trichomonas_vaginalis.G3`              text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Trypanosoma_brucei.TREU927`            text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `Vitrella_brassicaformis`               text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `protein_list`                      longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `protein_count`                         int DEFAULT NULL,
  PRIMARY KEY (`assoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
DROP TABLE IF EXISTS `presets`;
CREATE TABLE `presets` (
  `assoc`       int(3) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `preset_id`   text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `preset_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `preset_taxa` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci
) ENGINE='InnoDB' COLLATE 'utf8mb4_general_ci';